//
//  Time_In_Words_Screen_SaverView.m
//  Time In Words Screen Saver
//
//  Created by Sarah Reichelt on 30/04/12.
//  Copyright (c) 2012 TrozWare. All rights reserved.
//

#import "Time_In_Words_Screen_SaverView.h"
#import "DateTimeText.h"
#import "TimeZoneTableDelegate.h"

#define kModuleName     @"net.troz.Time-In-Words-Screen-Saver"


@implementation Time_In_Words_Screen_SaverView


- (id)initWithFrame:(NSRect)frame isPreview:(BOOL)isPreview
{
    self = [super initWithFrame:frame isPreview:isPreview];
    if (self) {
        // screen savers use a special form of user defaults, this just sets up the defaults
        ScreenSaverDefaults *defaults = [ScreenSaverDefaults defaultsForModuleWithName:kModuleName];
        [defaults registerDefaults:@{@"UseAlternativeZone": @"NO",
                                    @"AlternativeZoneName": @""}];
        
        // this sets the speed at which the screen saver will change its display
        [self setAnimationTimeInterval:1/30.0];
        
        // initialising the movement direction of the text
        self.changeBy = NSMakePoint(1, 1);
        
        // gather the string that will be shown
        self.timeAndDateString = [self textToDisplay];
    }
    return self;
}


- (BOOL)isOpaque {
    // this keeps Cocoa from unneccessarily redrawing our superview
    return YES;
}


// Standard functions created for you when you create a screen saver project in Xcode
- (void)startAnimation
{
    [super startAnimation];
}

- (void)stopAnimation
{
    [super stopAnimation];
}

- (void)drawRect:(NSRect)rect
{
    [super drawRect:rect];
}

- (void)animateOneFrame
{
    // I use this one to do the display rather than drawRect
    [self showDateAndTime];
    
    return;
}


// MARK: -
// MARK: Config


- (BOOL)hasConfigureSheet
{
    // return YES if the screen saver has a preference window
    return YES;
}


- (NSWindow*)configureSheet
{
    // Load the preferences window
    
    if (!self.configWindow)
    {
        // open it from the xib file if is hasn't already been opened
        // replicate the settings for the window in the xib file to make it open as a sheet
        if (![NSBundle loadNibNamed:@"Config" owner:self]) 
        {
            NSLog( @"Failed to load configure sheet." );
            NSBeep();
        }
    }
    
    // read the current settings
    ScreenSaverDefaults *defaults = [ScreenSaverDefaults defaultsForModuleWithName:kModuleName];
    BOOL useAlternativeZone = [defaults boolForKey:@"UseAlternativeZone"];
    NSString *timeZoneName = [defaults objectForKey:@"AlternativeZoneName"];
    NSInteger lineNum = -1;
    
    // display the curent settings in the window
    if (!useAlternativeZone) {
        [self.localTimeRadio setState:NSOnState];
        [self.alternativeTimeRadio setState:NSOffState];
        [self.timeZoneTable setEnabled:NO];
        [self.searchField setEnabled:NO];
    }
    else {
        [self.localTimeRadio setState:NSOffState];
        [self.alternativeTimeRadio setState:NSOnState];
        [self.timeZoneTable setEnabled:YES];
        [self.searchField setEnabled:YES];
        
        TimeZoneTableDelegate *delegate = (TimeZoneTableDelegate *) [self.timeZoneTable delegate];
        lineNum = [delegate findLineNumberForZone:timeZoneName];
    }
    
    if (lineNum == -1) {
        [self.timeZoneTable deselectAll:nil];
        [self.timeZoneTable scrollRowToVisible:0];
    }
    else {
        [self.timeZoneTable selectRowIndexes:[NSIndexSet indexSetWithIndex:lineNum] byExtendingSelection:NO];
        [self.timeZoneTable scrollRowToVisible:lineNum];
    }
    
    // return a reference to this window
    return self.configWindow;
}


- (IBAction)closeConfig:(id)sender
{
    // called by the OK button in the preferences window
    
    BOOL useAlternative = NO;
    NSString *alternativeZoneName = @"";
    
    if (![self.localTimeRadio state] == NSOnState) {
        useAlternative = YES;
        
        NSInteger selectedRow = [self.timeZoneTable selectedRow];
        if (selectedRow != -1) {
            TimeZoneTableDelegate *delegate = (TimeZoneTableDelegate *) [self.timeZoneTable delegate];
            alternativeZoneName = [delegate timeZoneArrayWithSearch][selectedRow][@"zone"];
        }
        else {
            useAlternative = NO;
        }
    }
    
    // save new settings
    ScreenSaverDefaults *defaults = [ScreenSaverDefaults defaultsForModuleWithName:kModuleName];
    [defaults setBool:useAlternative forKey:@"UseAlternativeZone"];
    [defaults setObject:alternativeZoneName forKey:@"AlternativeZoneName"];
    [defaults synchronize];
    
    // refresh in case there have been any changes
    self.timeAndDateString = [self textToDisplay];
    
    // close the window
    [[NSApplication sharedApplication] endSheet:self.configWindow];
}


- (IBAction)localTimeSelected:(id)sender
{
    // called when "Show Local Time" radio button is selected
    [self.timeZoneTable setEnabled:NO];
    [self.searchField setEnabled:NO];
    [self.timeZoneTable deselectAll:nil];
    [self.timeZoneTable scrollRowToVisible:0];
}


- (IBAction)alternativeTimeSelected:(id)sender
{
    // called when "Show Alternative Time" radio button is selected
    [self.timeZoneTable setEnabled:YES];
    [self.searchField setEnabled:YES];
    [self.searchField.window makeFirstResponder:self.searchField];
    [self.timeZoneTable deselectAll:nil];
    [self.timeZoneTable scrollRowToVisible:0];
}


- (IBAction)searchZones:(NSSearchField *)sender
{
    // called when anything is typed into the search field
    TimeZoneTableDelegate *delegate = (TimeZoneTableDelegate *) [self.timeZoneTable delegate];
    [delegate searchForZone:[sender stringValue]];
    [self.timeZoneTable reloadData];
}



#pragma mark -  Display


- (NSColor *)randomColor
{
    // The screen saver library has its own random functions
    // this one is used to pick a random color
    int colorTag = SSRandomIntBetween(1, 5);
    
    switch (colorTag) {
        case 1:
            return [NSColor yellowColor];
            break;
        case 2:
            return [NSColor cyanColor];
            break;
        case 3:
            return [NSColor magentaColor];
            break;
        case 4:
            return[NSColor greenColor];
            break;
        case 5:
            return [NSColor orangeColor];
            break;
            
        default:
            return [NSColor yellowColor];
            break;
    }
}


- (NSRect)randomRectForSize:(NSSize)requiredSize
{
    // always use [self bounds] to get the dimensions as this adjusts for the preview window
    // as well as for various screen resolutions
    NSRect viewBounds = [self bounds];
    CGFloat screenWidth = viewBounds.size.width;
    CGFloat screenHeight = viewBounds.size.height;
    
    CGFloat textWidth = requiredSize.width;
    CGFloat textHeight = requiredSize.height;
    
    // again, using a screen saver random function to create a randomly placed rect
    
    // left = random from 0 to screenWidth - textWidth
    // top = random from 0 to screenHeight - textHeight
    CGFloat textLeft = SSRandomFloatBetween(0, screenWidth - textWidth);
    CGFloat textTop = SSRandomFloatBetween(0, screenHeight - textHeight);
    
    NSRect textRect = NSMakeRect(textLeft, textTop, textWidth, textHeight);
    return textRect;
}


- (NSRect)adjustCurrentRect:(NSRect)theRect forSize:(NSSize)requiredSize
{
    // adjust the width & height of the rect without changing the origin
    
    CGFloat textWidth = requiredSize.width;
    CGFloat textHeight = requiredSize.height;
    
    NSRect textRect = NSMakeRect(theRect.origin.x, theRect.origin.y, textWidth, textHeight);
    return textRect;
}


- (BOOL)rectIsOutOfBounds:(NSRect)theRect
{
    // test if any part of the rect is outside the screen
    
    if (theRect.origin.x < 0 || theRect.origin.y < 0)
        return YES;
    
    NSRect viewBounds = [self bounds];
    if (theRect.origin.x + theRect.size.width > viewBounds.size.width)
        return YES;
    if (theRect.origin.y + theRect.size.height > viewBounds.size.height)
        return YES;

    return NO;
}


- (NSPoint)changeDirection:(NSRect)theRect
{
    // change direction to "bounce" the display off the edges
    
    NSRect viewBounds = [self bounds];
    NSPoint newChangeBy = self.changeBy;

    if (theRect.origin.x < 0)
        newChangeBy.x = 1;
    
    else if (theRect.origin.y < 0)
        newChangeBy.y = 1;
    
    else if (theRect.origin.x + theRect.size.width > viewBounds.size.width)
        newChangeBy.x = -1;
    
    else if (theRect.origin.y + theRect.size.height > viewBounds.size.height)
        newChangeBy.y = -1;
    
    return newChangeBy;
}


- (NSString *)textToDisplay
{
    // Use my DateTimeText class to get the text to display
    // As it was written for a different app, the returned text needs slight modifications
    
    DateTimeText *dateTime =  [[DateTimeText alloc] init];
    NSString *timeString;
    
    ScreenSaverDefaults *defaults = [ScreenSaverDefaults defaultsForModuleWithName:kModuleName];
    BOOL useAlternativeZone = [defaults boolForKey:@"UseAlternativeZone"];
    
    if (!useAlternativeZone) {
        timeString = [dateTime preciseTimeInWordsForDate:nil];
        
        timeString = [timeString lowercaseString];
        NSRange firstWord = NSMakeRange(0, 2);
        timeString = [timeString stringByReplacingCharactersInRange:firstWord withString:@"It"];
        timeString = [timeString stringByAppendingFormat:@" %@.", [dateTime dateInWords]];
        
    }
    else {
        NSString *timeZoneName = [defaults objectForKey:@"AlternativeZoneName"];
        timeString = [dateTime timeAsStringForZone:timeZoneName];
    }
    
    [dateTime release];
    return timeString;
}


- (void)showDateAndTime
{
    // This is the method that actually displays the text on screen
    
    // If any text has previously been drawn, black out it's rect to clear it
    if (self.textDrawingRect.size.width > 0) {
        [[NSColor blackColor] set];
        [NSBezierPath fillRect:self.frame];
    }

    // adjust font size to suit screen size: screen width / 50
    CGFloat fontSize = [self bounds].size.width / 50;
    if (fontSize < 10)
        fontSize = 10;
    
    NSDictionary *textAttribs = @{NSFontAttributeName: [NSFont boldSystemFontOfSize:fontSize]};
    
    // wrap text to standard width based on chosen font size
    CGFloat wrapWidth = fontSize * 12;
    NSString *wrappedText = [self wrapString:self.timeAndDateString 
                                    toLength:wrapWidth 
                              withAttributes:textAttribs];
    
    // work out how big a rect this text will need
    NSSize textSize = [wrappedText sizeWithAttributes:textAttribs];
    
    if (self.textDrawingRect.size.width == 0) {
        // if this is the first time the text has been drawn, start at a random location
        self.textDrawingRect = [self randomRectForSize:textSize];
        self.textDrawingColor = [self randomColor];
    }
    
    else {
        // move text diagonally until it hits an edge
        // then alter course by 90 degrees and change color
        
        // calculate where the new rect would be after it had moved
        NSRect newRect = self.textDrawingRect;
        newRect.origin.x += self.changeBy.x;
        newRect.origin.y += self.changeBy.y;
        
        // test if any part of this new rect would be outside the screen
        if ([self rectIsOutOfBounds:newRect]) {
            
            // if so, change the direction and recalculate the new rect
            self.changeBy = [self changeDirection:newRect];
            NSRect newRect = self.textDrawingRect;
            newRect.origin.x += self.changeBy.x;
            newRect.origin.y += self.changeBy.y;
            self.textDrawingRect = newRect;

            // should not use the same color twice in a row, but don't want to change color too quickly (sometimes it gets stuck in a corner & flickers)
            BOOL pickNewColor = YES;
            if (self.lastColorChange && self.textDrawingColor) {
                NSTimeInterval timeSinceLastChange = -[self.lastColorChange timeIntervalSinceNow];
                if (timeSinceLastChange < 0.5)
                    pickNewColor = NO;
            }
            
            if (pickNewColor) {
                NSColor *newColor = [self randomColor];
                if (self.textDrawingColor) {
                    while ([newColor isEqual:self.textDrawingColor]) {
                        newColor = [self randomColor];
                    }
                }
                self.textDrawingColor = newColor;
                self.lastColorChange = [NSDate date];
            }
            
            // only update time at the edges, and re-size the rect to fit
            self.timeAndDateString = [self textToDisplay];
            self.textDrawingRect = [self adjustCurrentRect:self.textDrawingRect forSize:textSize];
            
        }
        else {
            // if the new rect would still be inside the screen, then use it
            self.textDrawingRect = newRect;
        }
    }
    
    // set up the text attributes for the display
    textAttribs = @{NSFontAttributeName: [NSFont boldSystemFontOfSize:fontSize],
                   NSForegroundColorAttributeName: self.textDrawingColor};

    // draw the string at the required location on the screen
    [wrappedText drawAtPoint:self.textDrawingRect.origin withAttributes:textAttribs];
}


- (NSString *)wrapString:(NSString *)string toLength:(CGFloat)len withAttributes:(NSDictionary *)attribs
{
    // utility function to wrap a string so no line is longer than the specified length
    
    NSMutableString *newString = [[[NSMutableString alloc] initWithCapacity:[string length]] autorelease];
    NSMutableArray *newLines = [[NSMutableArray alloc] initWithCapacity:10];
    
    NSArray *words = [string componentsSeparatedByString:@" "];
    
    for (NSString *theWord in words) {
        if ([newString isEqualToString:@""])
            [newString appendString:theWord];
        else {
            NSString *testString = [newString stringByAppendingFormat:@" %@", theWord];
            NSSize testSize = [testString sizeWithAttributes:attribs];
            if (testSize.width > len) {
                [newLines addObject:newString];
                newString = [[theWord mutableCopy] autorelease];
            }
            else {
                [newString appendFormat:@" %@", theWord];
            }
        }
    }
    [newLines addObject:newString];
    [newLines autorelease];
    
    return [newLines componentsJoinedByString:@"\n"];
}


@end
