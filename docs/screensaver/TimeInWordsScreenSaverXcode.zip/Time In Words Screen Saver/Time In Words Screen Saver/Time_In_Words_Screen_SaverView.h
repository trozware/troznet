//
//  Time_In_Words_Screen_SaverView.h
//  Time In Words Screen Saver
//
//  Created by Sarah Reichelt on 30/04/12.
//  Copyright (c) 2012 TrozWare. All rights reserved.
//

#import <ScreenSaver/ScreenSaver.h>

@interface Time_In_Words_Screen_SaverView : ScreenSaverView


// properties used is drawing the screen saver display
@property (strong) NSString *timeAndDateString;
@property NSRect textDrawingRect;
@property (strong) NSColor *textDrawingColor;
@property NSPoint changeBy;
@property (strong) NSDate *lastColorChange;


// outlets in preferences window
@property (assign) IBOutlet NSWindow *configWindow;
@property (assign) IBOutlet NSButtonCell *localTimeRadio;
@property (assign) IBOutlet NSButtonCell *alternativeTimeRadio;
@property (assign) IBOutlet NSTableView *timeZoneTable;
@property (assign) IBOutlet NSSearchField *searchField;


@end
