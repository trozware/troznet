//
//  TimeZoneTableDelegate.h
//  Time In Words
//
//  Created by Sarah Reichelt on 23/02/2012.
//  Copyright (c) 2012 TrozWare. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeZoneTableDelegate : NSObject <NSTableViewDelegate, NSTableViewDataSource>
{
    IBOutlet NSTableView *zoneTable;

    NSArray *timeZoneArray, *timeZoneArrayWithSearch;
}

@property (strong) NSArray *timeZoneArray;
@property (strong) NSArray *timeZoneArrayWithSearch;


- (NSArray *)timeZones;
- (NSString *)secondsToHours:(NSInteger)seconds;

- (void)searchForZone:(NSString *)searchZone;
- (NSInteger)findLineNumberForZone:(NSString *)theZone;


@end
