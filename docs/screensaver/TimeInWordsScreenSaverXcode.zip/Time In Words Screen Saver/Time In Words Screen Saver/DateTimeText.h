//
//  DateTimeText.h
//  Time In Words
//
//  Created by Sarah Reichelt on 28/12/11.
//  Copyright (c) 2011 TrozWare. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DateTimeText : NSObject

- (NSString *)preciseTimeInWordsForDate:(NSDate *)forDate;
- (NSString *)timeAsStringForZone:(NSString *)timeZone;

- (NSString *)dateInWords;
- (NSString *)numberToText:(NSInteger)theNumber indexed:(BOOL)indexed;

@end
