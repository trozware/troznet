//
//  TimeZoneTableDelegate.m
//  Time In Words
//
//  Created by Sarah Reichelt on 23/02/2012.
//  Copyright (c) 2012 TrozWare. All rights reserved.
//

#import "TimeZoneTableDelegate.h"

@implementation TimeZoneTableDelegate

@synthesize timeZoneArray;
@synthesize timeZoneArrayWithSearch;


#pragma mark - Time zones table data source & delegate methods


- (NSInteger)numberOfRowsInTableView:(NSTableView *)aTableView
{
    if (!timeZoneArray || !timeZoneArrayWithSearch) {
        timeZoneArray = [self timeZones];
        timeZoneArrayWithSearch = [timeZoneArray copy];
    }
    
    return [timeZoneArrayWithSearch count];
}


- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
    if (!timeZoneArray || !timeZoneArrayWithSearch) {
        timeZoneArray = [self timeZones];
        timeZoneArrayWithSearch = [timeZoneArray copy];
    }

    NSDictionary *rowDict = timeZoneArrayWithSearch[rowIndex];
    return rowDict[[aTableColumn identifier]];
}


- (void)searchForZone:(NSString *)searchZone
{
    if (!timeZoneArray || !timeZoneArrayWithSearch) {
        timeZoneArray = [self timeZones];
        timeZoneArrayWithSearch = [timeZoneArray copy];
    }
    
    // THIS DOESN'T WORK UNDER MOUNTAIN LION!
    //
    //    NSArray *searchArray = [timeZoneArray copy];
    //
    //    if (![searchZone isEqualToString:@""]) {
    //        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"zone CONTAINS[cd] %@", searchZone];
    //        searchArray = [searchArray filteredArrayUsingPredicate:predicate];
    //    }
    //
    //    timeZoneArrayWithSearch = searchArray;
    
    //    NSLog(@"timeZoneArray class: %@", [timeZoneArray class]);
    //    NSLog(@"timeZoneArray count: %ld", [timeZoneArray count]);
    
    // So have to search manually
    if (![searchZone isEqualToString:@""]) {
        NSString *searchFor = [searchZone lowercaseString];
        NSMutableArray *matchingZones = [[NSMutableArray alloc] initWithCapacity:[timeZoneArray count]];
        for (NSDictionary *theZone in timeZoneArray) {
            NSString *zoneName = [theZone[@"zone"] lowercaseString];
            if ([zoneName rangeOfString:searchFor].location != NSNotFound)
                [matchingZones addObject:theZone];
        }
        
        timeZoneArrayWithSearch = [matchingZones copy];
        [matchingZones release];
    }
    else {
        timeZoneArrayWithSearch = [timeZoneArray copy];
    }
}



- (NSArray *)timeZones
{
    NSArray *timeZones = [NSTimeZone knownTimeZoneNames];
    NSMutableArray *tempArray = [[[NSMutableArray alloc] init] autorelease];
    NSDate *tNow = [NSDate date];
    
    for (NSString *zoneName in timeZones) {
        NSTimeZone *thisZone = [NSTimeZone timeZoneWithName:zoneName];
        NSString *abbrev = [thisZone abbreviationForDate:tNow];
        NSString *timeDiffString = [self secondsToHours:[thisZone secondsFromGMTForDate:tNow]];
        zoneName = [zoneName stringByReplacingOccurrencesOfString:@"_" withString:@" "];
        
        NSDictionary *zoneDict = @{@"zone": zoneName, @"abbrev": abbrev, 
                                  @"offset": timeDiffString};
        
        [tempArray addObject:zoneDict];
    }
    
    return [[tempArray copy] autorelease];
}


- (NSString *)secondsToHours:(NSInteger)seconds
{
    NSInteger mins = seconds / 60;
    NSInteger hours = mins / 60;
    mins = mins % 60;
    if (mins < 0)
        mins = -mins;
    
    NSString *prefix = @"+";
    if (hours < 0) {
        prefix = @"-";
        hours = -hours;
    }
    
    NSString *hourString = [NSString stringWithFormat:@"0%ld", hours];
    if ([hourString length] > 2)
        hourString = [hourString substringFromIndex:1];

    NSString *minString = [NSString stringWithFormat:@"0%ld", mins];
    if ([minString length] > 2)
        minString = [minString substringFromIndex:1];
    
    NSString *timeString = [NSString stringWithFormat:@"%@%@:%@", prefix, hourString, minString];
    return timeString;
}


- (NSInteger)findLineNumberForZone:(NSString *)theZone
{
    if (!timeZoneArray || !timeZoneArrayWithSearch) {
        timeZoneArray = [self timeZones];
        timeZoneArrayWithSearch = [timeZoneArray copy];
    }
    
    NSUInteger lineNum = -1;
    NSArray *matches = [timeZoneArrayWithSearch filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"zone CONTAINS[cd] %@", theZone]];
    if ([matches count] == 0)
        return -1;
    
    lineNum = [timeZoneArrayWithSearch indexOfObject:matches[0]];
    if (lineNum == NSNotFound)
        lineNum = -1;
    
    return lineNum;
}


@end
