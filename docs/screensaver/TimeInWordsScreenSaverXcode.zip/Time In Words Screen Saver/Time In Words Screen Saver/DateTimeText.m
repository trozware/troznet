//
//  DateTimeText.m
//  Time In Words
//
//  Created by Sarah Reichelt on 28/12/11.
//  Copyright (c) 2011 TrozWare. All rights reserved.
//

#import "DateTimeText.h"

@implementation DateTimeText


- (NSString *)preciseTimeInWordsForDate:(NSDate *)forDate
{
    NSMutableArray *timeWordsArray = [NSMutableArray arrayWithCapacity:5];
    [timeWordsArray addObject:@"IT IS"];
    
    NSDate *theTime = [NSDate date];
    if (forDate)
        theTime = forDate;
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    unsigned unitFlags = NSHourCalendarUnit | NSMinuteCalendarUnit;
    NSDateComponents *dateBits = [gregorian components:unitFlags fromDate:theTime];
    
    NSInteger hours = [dateBits hour];    
    NSInteger mins = [dateBits minute];
    
    BOOL pm = NO;
    if (hours > 12) {
        hours -= 12;
        pm = YES;
    }
    if (hours == 12)
        pm = YES;
    
    // convert hour to upper-case text (array has extra member to allow for next hour)
    NSArray *hourNames = @[@"MIDNIGHT", @"ONE", @"TWO", @"THREE", @"FOUR", @"FIVE", @"SIX", 
                          @"SEVEN", @"EIGHT", @"NINE", @"TEN", @"ELEVEN", @"MIDDAY", @"ONE"];
    NSString *theHour = hourNames[hours];
    NSString *theNextHour = hourNames[hours+1];
    
    if (pm && hours == 11) {
        theNextHour = @"MIDNIGHT";
    }
    
    if (mins == 0) {
        [timeWordsArray addObject:theHour];
        if (hours != 0 && hours != 12)
            [timeWordsArray addObject:@"O'CLOCK"];
    }
    else if (mins == 15) {
        [timeWordsArray addObject:@"QUARTER"];
        [timeWordsArray addObject:@"PAST"];
        [timeWordsArray addObject:theHour];
    }
    else if (mins == 30) {
        [timeWordsArray addObject:@"HALF"];
        [timeWordsArray addObject:@"PAST"];
        [timeWordsArray addObject:theHour];
    }
    else if (mins == 45) {
        [timeWordsArray addObject:@"QUARTER"];
        [timeWordsArray addObject:@"TO"];
        [timeWordsArray addObject:theNextHour];
    }
    else if (mins < 30) {
        [timeWordsArray addObject:[self numberToText:mins indexed:NO]];
        if (mins == 1)
            [timeWordsArray addObject:@"MINUTE"];
        else
            [timeWordsArray addObject:@"MINUTES"];
        [timeWordsArray addObject:@"PAST"];
        [timeWordsArray addObject:theHour];
    }
    else {
        // convert mins past to mins to the next hour
        [timeWordsArray addObject:[self numberToText:60 - mins indexed:NO]];
        if (mins == 59)
            [timeWordsArray addObject:@"MINUTE"];
        else
            [timeWordsArray addObject:@"MINUTES"];
        [timeWordsArray addObject:@"TO"];
        [timeWordsArray addObject:theNextHour];
    }
    
    if (pm && [timeWordsArray indexOfObject:@"MIDDAY"] == NSNotFound) {
        if (hours <= 5 || hours == 12)
            [timeWordsArray addObject:@"IN THE AFTERNOON"];
        else
            [timeWordsArray addObject:@"IN THE EVENING"];
    }
    else {
        [timeWordsArray addObject:@"IN THE MORNING"];
    }
    
    NSString *timeString = [timeWordsArray componentsJoinedByString:@" "];
    
    [gregorian release];
    
    return [timeString lowercaseString];
}


- (NSString *)timeAsStringForZone:(NSString *)timeZone
{
    timeZone = [timeZone stringByReplacingOccurrencesOfString:@" " withString:@"_"];
    
    if ([timeZone hasSuffix:@"/"])
        timeZone = [timeZone substringToIndex:[timeZone length] - 1];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];  
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    [dateFormatter setTimeStyle:NSDateFormatterLongStyle];  
    
    NSDate* sourceDate = [NSDate date];
    NSTimeZone* sourceTimeZone = [NSTimeZone systemTimeZone];
    NSTimeZone* destinationTimeZone = [NSTimeZone timeZoneWithName:timeZone];
    NSInteger sourceGMTOffset = [sourceTimeZone secondsFromGMTForDate:sourceDate];
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:sourceDate];
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;
    NSDate* destinationDate = [[NSDate alloc] initWithTimeInterval:interval sinceDate:sourceDate];
    
    NSInteger slashPos = [timeZone rangeOfString:@"/"].location;
    NSString *city = @"";
    if (slashPos != NSNotFound) {
        city = [timeZone substringFromIndex:slashPos+1];
        slashPos = [city rangeOfString:@"/"].location;
        if (slashPos != NSNotFound)
            city = [city substringFromIndex:slashPos+1];
    }
    
    city = [city capitalizedString];
    city = [city stringByReplacingOccurrencesOfString:@"_" withString:@" "];
    
    NSMutableString *timeString = [[[NSMutableString alloc] init] autorelease];
    if (![city isEqualToString:@""])
        timeString = [NSMutableString stringWithFormat:@"In %@\n", city];
    
    NSString *preciseTime = [self preciseTimeInWordsForDate:destinationDate];
//    [dateFormatter setDateFormat:@"EEEE"];
//    NSString *weekDay = [[dateFormatter stringFromDate:destinationDate] capitalizedString];
    NSString *weekDay = [[self dayOfWeekInEnglish:destinationDate] capitalizedString];
    weekDay = [NSString stringWithFormat:@" on %@ ", weekDay];
    
    if ([preciseTime rangeOfString:@" in the "].location == NSNotFound) {
        weekDay = [weekDay stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        preciseTime = [preciseTime stringByAppendingFormat:@" %@", weekDay];
    }
    else {
        preciseTime = [preciseTime stringByReplacingOccurrencesOfString:@" in the " withString:weekDay];
    }
    [timeString appendString:preciseTime];
    
    NSString *formattedZone = [destinationTimeZone abbreviationForDate:destinationDate];
    if ([city isEqualToString:@""])
        [timeString appendFormat:@" %@", formattedZone];
        
    if ([destinationTimeZone isDaylightSavingTimeForDate:destinationDate])
        [timeString appendString:@"\n(daylight savings time)."];
    else
        [timeString appendString:@"."];

    [dateFormatter release];
    [destinationDate release];
    
    return timeString;
}
    

- (NSString *)dateInWords
{
    NSDate *theDate = [NSDate date];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];  
//    [dateFormatter setDateFormat:@"EEEE"];
//    NSString *weekDay = [[dateFormatter stringFromDate:theDate] uppercaseString];
    NSString *weekDay = [[self dayOfWeekInEnglish:theDate] uppercaseString];
    
//    [dateFormatter setDateFormat:@"MMMM"];
//    NSString *monthName = [[dateFormatter stringFromDate:theDate] uppercaseString];
    NSString *monthName = [[self monthInEnglish:theDate] uppercaseString];
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *dateBits = [gregorian components:NSDayCalendarUnit | NSYearCalendarUnit fromDate:theDate];
    NSInteger theDay = [dateBits day];
    NSInteger theYear = [dateBits year];
    
    NSString *dayString = [self numberToText:theDay indexed:YES];
    NSString *yearString = [self numberToText:theYear indexed:NO];
    yearString = [@"TWO THOUSAND AND " stringByAppendingString:yearString];
    
    weekDay = [weekDay capitalizedString];
    dayString = [dayString lowercaseString];
    monthName = [monthName capitalizedString];
    yearString = [yearString lowercaseString];
    
    NSString *dateString = [NSString stringWithFormat:@"on %@ the %@ of %@, %@", weekDay, dayString,
                            monthName, yearString];
    
    [dateFormatter release];
    [gregorian release];
    
    return dateString;
}



- (NSString *)numberToText:(NSInteger)theNumber indexed:(BOOL)indexed
{
    // only goes up to 99
    if (theNumber > 99) {
        theNumber = theNumber % 100;
    }
    
    NSArray *numberStrings;
    if (indexed)
        numberStrings = @[@"FIRST", @"SECOND", @"THIRD", @"FOURTH", 
                         @"FIFTH", @"SIXTH", @"SEVENTH", @"EIGHTH", @"NINTH", @"TENTH", 
                         @"ELEVENTH", @"TWELFTH", @"THIRTEENTH", @"FOURTEENTH", @"FIFTEENTH",
                         @"SIXTEENTH", @"SEVENTEENTH", @"EIGHTEENTH", @"NINETEENTH", @"TWENTIETH"];
    else
        numberStrings = @[@"ONE", @"TWO", @"THREE", @"FOUR", @"FIVE", @"SIX", 
                         @"SEVEN", @"EIGHT", @"NINE", @"TEN", @"ELEVEN", @"TWELVE"
                         , @"THIRTEEN", @"FOURTEEN", @"FIFTEEN", @"SIXTEEN", @"SEVENTEEN"
                         , @"EIGHTEEN", @"NINETEEN", @"TWENTY"];
    
    NSArray *evenTenStrings = @[@"", @"TENTH", @"TWENTIETH", @"THIRTIETH", @"FORTIETH", @"FIFTIETH", 
                               @"SIXTIETH", @"SEVENTIETH", @"EIGHTIETH", @"NINETIETH"];
    
    NSArray *tenStrings = @[@"TWENTY-", @"THIRTY-", @"FORTY-", @"FIFTY-", 
                           @"SIXTY-", @"SEVENTY-", @"EIGHTY-", @"NINETY-"];
    
    NSString *numString = @"";
    if (theNumber <= 20)
        numString = numberStrings[theNumber-1];
    else {
        NSInteger modNumber = theNumber % 10;
        if (modNumber == 0) {
            numString = evenTenStrings[theNumber / 10];
        }
        else {
            NSInteger theTens = (theNumber - modNumber) / 10;
            numString = [NSString stringWithFormat:@"%@%@", tenStrings[theTens-2],
                         numberStrings[modNumber-1]];
        }
    }
    
    return numString;
}


- (NSString *)dayOfWeekInEnglish:(NSDate *)date
{
    NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
    NSUInteger firstDay = [calendar firstWeekday] - 1;
    // subtract 1 to zero-index: Aus (sun) = 0, Fra (mon) = 1
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"e"];
    NSInteger weekDayNumber = [[dateFormatter stringFromDate:date] integerValue];
    // Aus Sunday = 1, Fra Sunday = 7
    
    // subtract 1 to zero-index the days, then add the firstDay offset
    weekDayNumber = weekDayNumber - 1 + firstDay;
    
    NSArray *englishDays = @[ @"Sunday", @"Monday", @"Tuesday", @"Wednesday", @"Thursday"
    , @"Friday", @"Saturday", @"Sunday"];
    
    NSString *day = englishDays[weekDayNumber];
    
    return day;
}


- (NSString *)shortDayOfWeekInEnglish:(NSDate *)date
{
    NSString *longDay = [self dayOfWeekInEnglish:date];
    
    return [longDay substringToIndex:3];
}


- (NSString *)monthInEnglish:(NSDate *)date
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"M"];
    NSInteger monthNumber = [[dateFormatter stringFromDate:date] integerValue] - 1;
    // subtract 1 to zero-index the months
    
    NSArray *englishMonths = @[ @"January", @"February", @"March", @"April", @"May", @"June", @"July"
    , @"August", @"September", @"October", @"November", @"December", @"January"];
    
    NSString *month = englishMonths[monthNumber];
    return month;
}


- (NSString *)shortMonthInEnglish:(NSDate *)date
{
    NSString *longMonth = [self monthInEnglish:date];
    
    return [longMonth substringToIndex:3];
}


@end
